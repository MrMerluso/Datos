Benjamín Aedo 201973039-8
Manuel Barahona 201973042-8
Sebastián Benavides 201973088-6
Nicolás Vivanco 201903032-5

-el formato del comando "add" siempre será "add <documento> to (hubert, javiera, john) stack"
-el comando "turn" siempre ira acompañado de un "on" u "off" separado por un espacio

Trabajamos en la tarea alrededor de 3 dias

Benjamin y Nicolas trabajaron en funciones principales del programa
Diego y Sebastiantrabajaron en los inputs y en el manejo de las funciones 

Lo mas complicado fue considerar el caso de que hubiera un "to" en el nombre del documento y dividir 
el comando de entrada acordemente